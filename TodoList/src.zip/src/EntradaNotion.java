import controller.Planificador;
import model.*;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Planificador planificador = new Planificador();
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println();
            System.out.println("1. Registrar tarea");
            System.out.println("2. Modificar tarea");
            System.out.println("3. Listar tareas");
            System.out.println("4. Completar tarea");
            System.out.println("5. Listar tareas completas");
            System.out.println("6. Listar tareas incompletas");
            System.out.println("7. Agregar persona a tarea");
            System.out.println("8. Agregar encargo a tarea");
            System.out.println("0. Salir");
            System.out.print("Opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1:
                    System.out.print("¿Es tarea personal (1) o profesional (2)? ");
                    int tipo = scanner.nextInt();

                    System.out.print("ID: ");
                    int id = scanner.nextInt();

                    System.out.print("Título: ");
                    String titulo = scanner.nextLine();

                    System.out.print("Descripción: ");
                    String descripcion = scanner.nextLine();

                    System.out.print("Fecha: ");
                    String fecha = scanner.nextLine();

                    System.out.print("Prioridad: ");
                    boolean prioridad = scanner.nextBoolean();

                    if (tipo == 1) {
                        System.out.print("Ubicación: ");
                        String ubicacion = scanner.nextLine();
                        System.out.print("Presupuesto: ");
                        double presupuesto = scanner.nextDouble();
                        scanner.nextLine();
                        new TareaPersonal(titulo,id, descripcion,  prioridad, ubicacion, presupuesto);
                    } else if (tipo == 2) {
                        System.out.print("Proyecto: ");
                        String proyecto = scanner.nextLine();
                        new TareaProfesional(titulo,id, descripcion, prioridad, proyecto);
                    } else {
                        System.out.println("Tipo inválido.");
                        break;
                    }

                    System.out.print("¿Depende de otra tarea? (s/n): ");
                    String depende = scanner.nextLine();
                    if (depende.equalsIgnoreCase("s")) {
                        System.out.print("ID de la tarea : ");
                        int idPadre = scanner.nextInt();
                        Tarea padre = planificador.buscarTarea(idPadre);
                        if (padre != null) {
                            padre.agregarSubtarea(padre);
                        } else {
                            System.out.println("Tarea no encontrada. Se agregará como tarea principal.");
                            planificador.agregarTarea();
                        }
                    } else {
                        planificador.agregarTarea();
                    }
                    break;

                case 2:
                    System.out.print("ID de la tarea a modificar: ");
                    int idMod = scanner.nextInt();
                    scanner.nextLine();
                    Tarea tareaMod = planificador.buscarTarea(idMod);
                    if (tareaMod != null) {
                        System.out.println("¿Qué deseas modificar?");
                        System.out.println("1. Título");
                        System.out.println("2. Descripción");
                        System.out.println("3. Fecha");
                        System.out.println("4. Prioridad");

                        if (tareaMod instanceof TareaPersonal) {
                            System.out.println("5. Ubicación");
                            System.out.println("6. Presupuesto");
                        } else if (tareaMod instanceof TareaProfesional) {
                            System.out.println("5. Proyecto");
                        }
                        int campo = scanner.nextInt();
                        switch (campo) {
                            case 1:
                                System.out.print("Nuevo título: ");
                                String tituloN = scanner.nextLine();
                                tareaMod.setTitulo(tituloN);
                                break;
                            case 2:
                                System.out.print("Nueva descripción: ");
                                String desc = scanner.nextLine();
                                tareaMod.setDescripcion(desc);
                                break;
                            case 3:
                                System.out.print("Nueva fecha: ");
                                String fechaN = scanner.nextLine();
                                break;
                            case 4:
                                System.out.print("Nueva prioridad: ");
                                boolean prioridadN = scanner.nextBoolean();
                                tareaMod.setPrioritario(prioridadN);
                                break;
                            case 5:
                                if (tareaMod instanceof TareaPersonal) {
                                    System.out.print("Nueva ubicación: ");
                                    ((TareaPersonal) tareaMod).setUbicacion(scanner.nextLine());
                                } else if (tareaMod instanceof TareaProfesional) {
                                    System.out.print("Nuevo proyecto: ");
                                    ((TareaProfesional) tareaMod).setProyecto(scanner.nextLine());
                                }
                                break;
                            case 6:
                                if (tareaMod instanceof TareaProfesional) {
                                    System.out.print("Nuevo presupuesto: ");
                                    ((TareaProfesional) tareaMod).setPresupuesto(scanner.nextInt());
                                }
                                break;
                            default:
                                System.out.println("Opción inválida.");
                        }
                    } else {
                        System.out.println("Tarea no encontrada.");
                    }
                    break;
                case 3:
                    planificador.listarTareas();
                    break;
                case 4:
                    System.out.print("ID de la tarea a completar: ");
                    int idComp = scanner.nextInt();
                    scanner.nextLine();
                    planificador.completarTarea(idComp);
                    break;
                case 5:
                    planificador.listarCompletas();
                    break;
                case 6:
                    planificador.listarIncompletas();
                    break;
                case 7:
                    System.out.print("ID de la tarea: ");
                    int idPersona = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Nombre de la persona: ");
                    String persona = scanner.nextLine();
                    planificador.asignarPersona(idPersona, new Persona());
                    break;

                case 8:
                    System.out.print("ID de la tarea: ");
                    int idEncargo = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Descripción del encargo: ");
                    String encargo = scanner.nextLine();
                    planificador.asignarEncargo(idEncargo,encargo );
                    break;

                case 0:
                    System.out.println("Saliendo...");
                    break;

                default:
                    System.out.println("Opción inválida.");
            }

        } while (opcion != 0);

    }
}
