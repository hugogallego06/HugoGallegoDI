package controller;
import model.Encargo;
import model.Persona;
import model.Tarea;

import java.util.*;

public class Planificador {
    private List<Tarea> tareas = new ArrayList<>();

    public void agregarTarea() {
        tareas.add(tarea);
    }

    public Tarea buscarTarea(int id) {
        for (Tarea t : tareas) {
            if (t.getId() == id) return t;
        }
        return null;
    }

    public void listarTareas() {
        for (Tarea t : tareas) {
            t.mostrarDatos();
        }
    }

    public void listarCompletas() {
        for (Tarea t : tareas) {
            if (t.isCompletada()) t.mostrarDatos();
        }
    }

    public void listarIncompletas() {
        for (Tarea t : tareas) {
            if (!t.isCompletada()) t.mostrarDatos();
        }
    }

    public void completarTarea(int id) {
        Tarea tarea = buscarTarea(id);
        if (tarea != null) {
            if (!tarea.isCompletada()) {
                tarea.completarTarea();
                System.out.println("Tarea completada.");
            } else {
                System.out.println("La tarea tiene subtareas sin completar.");
            }
        } else {
            System.out.println("Tarea no encontrada.");
        }
    }

    public void asignarPersona(int id, Persona persona) {
        Tarea t = buscarTarea(id);
        if (t != null) t.asignarResponsable(persona);
    }

    public void asignarEncargo(int id , Encargo encargo) {
        Tarea t = buscarTarea(id);
        if (t != null) t.agregarEncargos(new Encargo());
    }
}
