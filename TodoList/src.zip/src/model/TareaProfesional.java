package model;

import java.util.Date;

public class TareaProfesional extends Tarea{
    /* private String titulo,descripcion;
    private boolean prioritario,completada;
    private Persona[] encargados;
    private ArrayList<Encargo> listaTareas;
    */

    private int presupuesto;
    private String fechaLimite;
    private String proyecto;


    public TareaProfesional(String titulo,int id, String descripcion, int numeroPersonas, int presupuesto, String fechaLimite){
        super(titulo,id,descripcion,numeroPersonas);
        this.fechaLimite=fechaLimite;
        this.presupuesto=presupuesto;
    }
    public TareaProfesional(String titulo,int id,String descripcion,int numeroPersonas,int presupuesto){
        super(titulo,id,descripcion,numeroPersonas);
        this.presupuesto = presupuesto;
    }

    public TareaProfesional(String titulo, int id,String descripcion, boolean prioritario,  String proyecto) {
        super(titulo, id,descripcion, prioritario);
        this.proyecto = proyecto;
    }
    public void enviarRecordatorio() {
        for (Persona persona:getEncargados()){
            if (persona != null) {
                System.out.printf("%s recuerda que hay que completar %d de tareas pendientes\n",
                        persona.getNombre(),getListaTareas().size());
            }
        }

    }
    public int getPresupuesto() {
        return presupuesto;
    }

    public void setPresupuesto(int presupuesto) {
        this.presupuesto = presupuesto;
    }

    public String getFechaLimite() {
        return fechaLimite;
    }

    public void setFechaLimite(String fechaLimite) {
        this.fechaLimite = fechaLimite;
    }

    public String getProyecto() {
        return proyecto;
    }

    public void setProyecto(String proyecto) {
        this.proyecto = proyecto;
    }

    @Override
    public String toString() {

        return super.toString()+"TareaProfesional{" +
                "presupuesto=" + presupuesto +
                ", fechaLimite=" + fechaLimite +
                '}';
    }
}
