package model;

import java.util.ArrayList;

abstract public class Tarea {

    // variables
    private String titulo,descripcion;
    private int id;
    private boolean prioritario,completada;
    private Persona[] encargados;
    private ArrayList<Tarea> listaTareas;
    // constructores
    public Tarea(){

    }
    // cada tarea puede asignar una persona solo se podra asignar una persona si hay hueco disponible
    // cada vez que se asigne una persona se debera colocar en el primer hueco disponilbe
    // si no hay hueco saltar aviso
    // no podras agregar dos personas que tengan el mismo DNI

    public Tarea(String titulo,int id,String descripcion,boolean prioritario){
        // completada=false;
        this.titulo=titulo;
        this.id=id;
        this.descripcion=descripcion;
        this.prioritario=prioritario;
        listaTareas= new ArrayList<Tarea>();
    }

    public Tarea(String titulo,int id,String descripcion,int numeroPersonas){
        // completada=false;
        // prioritario=false;
        this.id=id;
        this.titulo=titulo;
        this.descripcion=descripcion;
        encargados = new Persona[numeroPersonas];
        listaTareas = new ArrayList<Tarea>();
    }

    // enviarRecordatorio -> Totalmente diferente en TPro Tper

    public abstract void enviarRecordatorio();

    public void asignarResponsable(Persona persona){
        for (int i = 0; i <encargados.length-1 ; i++) {
            if (encargados[i] == null && !estarDNI(persona.getDni())) {
                encargados[i]=persona;
                System.out.println("Persona agragada correctamente");
                return;
            }
        }
        System.out.println("No hay hueco disponible. Tarea completa");
    }

    public void agregarSubtarea(Tarea t) {
        listaTareas.add(t);
    }

    // en una tarea se pueden quitar responsables. Solo podre quitar una tarea si el DNI
    // que me indicas esta dentro de la lista de responsable.Mostrar aviso tanto para
    // proceso OK como proceso no OK

    public void eliminarResponsable(String dni){
        for (Persona persona:encargados) {
            if (persona != null && persona.getDni().equalsIgnoreCase(dni)) {
                persona=null;
                System.out.println("Persona eliminada correctamente");
                return;
            }
        }
        System.out.printf("La persona con DNI %s no esta en esta tarea \n",dni);
    }

    // mostrar los datos de todos los usuarios que son responsables de dichas tareas
    // en caso de no tener ninguna avisar
    // en caso de tener hueco disponible, avisar de cuantos

    public void mostrarDatos(){
        int hueco=0;
        for (Persona persona1: encargados){
            if (persona1 == null) {
                hueco++;
            }else{
            System.out.println(persona1);
            }
        }
        if (hueco != 0) {
        System.out.println("Los huecos "+hueco);
        } else if (hueco== encargados.length){
            System.out.println("No hay responsables asignados");
        }
         else{
            System.out.println("Todos los responsables estan ubiucados");
        }
    }
    private boolean estarDNI(String dni) {
        for (Persona persona : encargados ) {
            if (persona!=null && persona.getDni().equalsIgnoreCase(dni)) {
                return true;
            }
        }
        return false;
    }
    // crear el metodo que permite agregar un encargo
    // los encargos deben tener ID unico -> PONER AVISOS
    // crear el metodo que permita eliminar un encargo

    private Tarea estaEncargo(int id){
        for (Tarea encargo : listaTareas){
            if (encargo.getId() == id) {
                return encargo;
            }
        }
        return null;
    }
    public void agregarEncargos(Tarea encargo){
        if (estaEncargo(encargo.getId()) != null) {
            System.out.println("Error en el proceso no se puede agregar");
        }else{
            listaTareas.add(encargo);
            System.out.println("Agregado correctamente");
        }
    }
    public void eliminarEncargo(int id){
        if (estaEncargo(id) != null) {
            listaTareas.remove(estaEncargo(id));
            System.out.println("Borrado correctamente");
        }else {
            System.out.println("No esta en la lista el id especificado");
        }
    }
    public void listarEncargos(){
        for (Tarea e : listaTareas){
            e.mostrarDatos();
        }
    }
    public void completarEncargo(int id){
        if (estaEncargo(id) != null && !estaEncargo(id).isCompletada()) {
            estaEncargo(id).setCompletada(true);
            System.out.println("Encargo completado correctamente");
        }else{
            System.out.println("El encargo no se puede completar no esta en la lista o ya esta completado");
        }
    }
    public void buscarEncargoID(int id){
        if (estaEncargo(id) != null) {
            estaEncargo(id).mostrarDatos();
        }else{
            System.out.println("El id no se encuentra en la lista");
        }
    }
    public void completarTarea(){
        for (Tarea e: listaTareas){
            if (!e.isCompletada()) {
                System.out.println("No se puede completar la tarea");
                return ;
            }
        }
        completada= true;
        System.out.println("Tarea completada con exito");
    }

    // crear los metodos de asignar un encargo a un responsable
    // para poder asignar un responsable al encargo previamente tiene que estar como integrante del equipo
    // cambiar los responsables de las tareas
    // y mostrar tareas por responsable ->DNI



    // metodos -> getter / setter

    public Persona[] getEncargados() {
        return encargados;
    }

    public void setEncargados(Persona[] encargados) {
        this.encargados = encargados;
    }

    public ArrayList<Tarea> getListaTareas() {
        return listaTareas;
    }

    public void setListaTareas(ArrayList<Tarea> listaTareas) {
        this.listaTareas = listaTareas;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public boolean isPrioritario() {
        return prioritario;
    }

    public void setPrioritario(boolean prioritario) {
        this.prioritario = prioritario;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean isCompletada() {
        return completada;
    }

    public void setCompletada(boolean completada) {
        this.completada = completada;
    }

    @Override
    public String toString() {
        return "Tarea{" +
                "titulo='" + titulo + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", id=" + id +
                ", prioritario=" + prioritario +
                ", completada=" + completada +
                '}';
    }
}
