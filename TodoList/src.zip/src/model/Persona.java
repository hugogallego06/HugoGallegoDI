package model;
// un tarea tiene asocidas una serie de personas
// cuando se crea la tarea es necesario pedir cuantas personas (NO QUE PERSONAS)
// encargaran la tarea
public class Persona {
    // nombre, apellido, dni, edad

    private String nombre, apellidos, dni;
    private int edad;

    public Persona(){}

    public Persona(String nombre, String apellidos, String dni, int edad) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.dni = dni;
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
}
