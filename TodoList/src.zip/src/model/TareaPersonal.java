package model;

public class TareaPersonal extends Tarea{

    @Override
    public void enviarRecordatorio() {
            System.out.printf("La ubicacion de esta tarea es %s",ubicacion);
        }

    private String ubicacion;
    private double presupuesto;

    public TareaPersonal() {

    }

    public TareaPersonal(String titulo,int id, String descripcion, boolean prioritario, String ubicacion, double presupuesto) {
        super(titulo,id, descripcion, prioritario);
        this.ubicacion = ubicacion;
        this.presupuesto= presupuesto;
    }

    public TareaPersonal(String titulo,int id, String descripcion, int numeroPersonas, String ubicacion) {
        super(titulo,id, descripcion, numeroPersonas);
        this.ubicacion = ubicacion;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    @Override
    public String toString() {
        return super.toString()+"TareaPersonal{" +
                "ubicacion='" + ubicacion + '\'' +
                '}';
    }
}
