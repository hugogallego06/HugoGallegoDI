package model;

import java.util.ArrayList;

// un encargo debe tener un responsable
public class Encargo {

    private String descripcion;

    private int id;

    private boolean completada;
    private ArrayList<Persona> responsables;

    public Encargo(String descripcion, int id) {
        this.descripcion = descripcion;
        this.id = id;
        responsables=new ArrayList<>();
    }
    public void asignarEncargo(Persona persona){
        responsables.add(persona);
    }
    public Encargo() {
    }

    public void mostrarDatos(){
        System.out.println("descripcion = " + descripcion);
        System.out.println("id = " + id);
        System.out.println("completada = " + completada);
    }
    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean isCompletada() {
        return completada;
    }

    public void setCompletada(boolean completada) {
        this.completada = completada;
    }

    @Override
    public String toString() {
        return "Encargo{" +
                "descripcion='" + descripcion + '\'' +
                ", id=" + id +
                ", completada=" + completada +
                '}';
    }
}
